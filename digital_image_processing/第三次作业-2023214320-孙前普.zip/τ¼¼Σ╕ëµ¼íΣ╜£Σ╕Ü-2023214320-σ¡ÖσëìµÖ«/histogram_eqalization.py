import cv2
import numpy as np
import matplotlib.pyplot as plt
import os
print(os.getcwd())

sceneview = cv2.imread("./digital_image_processing/Homework_3/sceneview.jpg", cv2.IMREAD_GRAYSCALE)
tungsten = cv2.imread("./digital_image_processing/Homework_3/tungsten_original.jpg", cv2.IMREAD_GRAYSCALE)
# print(sceneview)
# hist = cv2.calcHist([sceneview], [0], None, [256], [0, 256])
# # f, ax = plt.subplots(2, 2)
# plt.hist(hist)

# plt.savefig("histogram.png")

print(sceneview.shape)
# print(np.squeeze(sceneview)
def hist_sum(img):
    h, w = img.shape
    hist = np.zeros(256, dtype=np.float64)
    for i in range(h):
        for j in range(w):
            hist[img[i, j]] += 1
    return hist

def cumsum(hist):
    cum_hist = np.zeros(256, dtype=np.float64)
    for i in range(256):
        cum_hist[i] = np.sum(hist[:i])
    return cum_hist

def histogram_eq(img):
    h, w = img.shape
    new_img = np.zeros((h, w), dtype=np.uint8)
    hist = hist_sum(img)
    hist = hist / (h * w)
    hist = np.around(cumsum(hist) * 255.0)
    new_img = hist[img]
    return new_img

if "__main__" == "__main__":
    f, ax = plt.subplots(2, 2, figsize=(10, 10))
    plt.subplots_adjust(wspace =0.5, hspace = 0.5)
    # 原图
    ax[0, 0].imshow(sceneview, cmap="gray")
    ax[0, 0].set_title("original")
    ax[1, 0].imshow(tungsten, cmap="gray")
    ax[1, 0].set_title("original")

    # # 直方图
    ax[0, 1].hist(sceneview.flatten(), 256)
    ax[0, 1].set_title("original-histogram")

    ax[1, 1].hist(tungsten.flatten(), 256)
    ax[1, 1].set_title("original-histogram")

    # 直方图均衡化
    sceneview_eq = cv2.equalizeHist(sceneview)
    sceneview_eq_script = histogram_eq(sceneview)
    tungsten_eq = cv2.equalizeHist(tungsten)
    tungsten_eq_script = histogram_eq(tungsten)
    # ax[0, 0].imshow(sceneview_eq, cmap="gray",)
    # ax[0, 0].set_title("OpenCV")

    # ax[0, 0].imshow(sceneview_eq_script, cmap="gray")
    # ax[0, 0].set_title("mine")
    
    # ax[1, 0].imshow(tungsten_eq, cmap="gray")
    # ax[1, 0].set_title("OpenCV")
    # 
    # ax[1, 0].imshow(tungsten_eq_script, cmap="gray")
    # ax[1, 0].set_title("mine")
    
    # 直方图
    # ax[0, 1].hist(sceneview_eq.flatten(), 256)
    # ax[0, 1].set_title("OpenCV")

    # ax[0, 1].hist(sceneview_eq_script.flatten(), 256)
    ax[0, 1].set_xlabel("bins")
    ax[0, 1].set_ylabel("nums")
    # ax[0, 1].set_title("mine")
    ax[0, 1].set_xticks(np.arange(0, 256, 25))
    ax[0, 1].set_yticks(np.arange(0, 10000, 1000))

    # ax[1, 1].hist(tungsten_eq.flatten(), 256)
    # ax[1, 1].set_title("OpenCV")

    # ax[1, 1].hist(tungsten_eq_script.flatten(), 256)
    ax[1, 1].set_xlabel("bins")
    ax[1, 1].set_ylabel("nums")
    # ax[1, 1].set_title("mine")
    ax[1, 1].set_xticks(np.arange(0, 256, 25))
    ax[1, 1].set_yticks(np.arange(0, 10000, 1000))

    plt.savefig("original.png")
