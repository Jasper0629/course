import random
import pickle
num = random.randint(1, 100)

def random_list():
    list = []
    while True:
        info = random.randint(1, 100)
        list.append(info)
        if len(list) == 100:
            break
    return list


if __name__ == '__main__':

    list = []
    list = random_list()

    with open('number_list.pkl', "wb") as f:
        pickle.dump(list, f)
    with open('number_list.pkl', 'rb') as f:
        new_list = pickle.load(f)

    new_list.sort()

    with open('new_number_list.txt', 'w') as f:
        f.write(str(new_list))
