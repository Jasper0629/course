
def quick_sort(my_list, left, right):
    if left < right:
        i = left - 1
        j = right + 1
        mid = my_list[(i + j) // 2]
        while i < j:
            while 1:
                i += 1
                if my_list[i] >= mid: break
            while 1:
                j -= 1
                if my_list[j] <= mid: break
            if i < j:
                my_list[i], my_list[j] = my_list[j], my_list[i]

        quick_sort(my_list, left, j)
        quick_sort(my_list, j + 1, right)

def merge_sort(list):
    if len(list) <= 1:
        return
    mid = len(list) // 2
    L = list[:mid]
    R = list[mid:]
    merge_sort(L)
    merge_sort(R)

    i = j = k = 0
    while i < len(L) and j < len(R):
        if L[i] <= R[j]:
            list[k] = L[i]
            i += 1
        else:
            list[k] = R[j]
            j += 1
        k += 1
    while i < len(L):
        list[k] = L[i]
        k += 1
        i += 1
    while j < len(R):
        list[k] = R[j]
        k += 1
        j += 1


class Heap():
    def __init__(self, nums, N):
        self.size = len(nums)
        self.m = 0
        self.ph = [0] * N
        self.hp = [0] * N
        self.h = [0] * N
        for i in range(1, len(nums) + 1):
            self.h[i] = nums[i - 1]

    def heapify(self):
        for i in range(self.size // 2, 0, -1):
            self.down(i)

    def heap_swap(self, a, b):
        self.h[a], self.h[b] = self.h[b], self.h[a]

    def down(self, u):
        t = u
        if u * 2 <= self.size and self.h[u * 2] < self.h[t]:
            t = u * 2
        if u * 2 + 1 <= self.size and self.h[u * 2 + 1] < self.h[t]:
            t = u * 2 + 1
        if u != t:
            self.heap_swap(u, t)
            self.down(t)

    def up(self, u):
        while u // 2 and self.h[u] < self.h[u // 2]:
            self.heap_swap(u, u // 2)
            u = u // 2

    def add(self, x):
        self.m += 1
        self.size += 1
        self.ph[self.m] = self.size
        self.hp[self.size] = self.m
        self.h[self.size] = x
        self.up(self.size)

    def get_min(self):
        return self.h[1]

    def delete_min(self):
        self.heap_swap(1, self.size)
        self.size -= 1
        self.down(1)




    def modify_k(self, k, x):
        # 修改第k个插入的数
        k = self.ph[k]
        self.h[k] = x
        self.down(k)
        self.up(k)

def bubble_sort(list):
    i = 0
    while(i < len(list)):
        j = 0
        while(j < len(list) - i - 1):
            if list[j] > list[j+1]:
                list[j], list[j+1] = list[j + 1], list[j]
            j = j + 1
        i = i + 1

def insertion_sort(list):
    for i in range(len(list)):
        cur_index = i
        while list[cur_index-1] > list[cur_index] and cur_index-1 >= 0:
            list[cur_index], list[cur_index-1] = list[cur_index-1], list[cur_index]
            cur_index -= 1


if __name__ == '__main__':
    # quick_sort
    list = [10, 17, 50, 7, 30, 24, 27, 45, 15, 5, 36, 21]
    quick_sort(list, 0, len(list) - 1)
    print("quick_sort:", list)

    # heap_sort
    list = [10, 17, 50, 7, 30, 24, 27, 45, 15, 5, 36, 21]
    h = Heap(list, 10 ** 5 + 1)
    h.heapify()
    res = []
    for i in range(len(list)):
        res.append(h.get_min())
        h.delete_min()
    print("heap_sort:", res)
    
    # merge_sort
    list = [10, 17, 50, 7, 30, 24, 27, 45, 15, 5, 36, 21]
    merge_sort(list)
    print("merge_sort:", list)

    # bubble_sort
    list = [10, 17, 50, 7, 30, 24, 27, 45, 15, 5, 36, 21]
    bubble_sort(list)
    print("bubble_sort:", list)

    list = [10, 17, 50, 7, 30, 24, 27, 45, 15, 5, 36, 21]
    insertion_sort(list)
    print("insert_sort:", list)

    
