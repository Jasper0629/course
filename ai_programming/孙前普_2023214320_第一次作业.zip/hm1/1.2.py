from collections import Counter
import os
import sys,io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="gb18030")
import re
dictionary = {}


def remove_punctuation(inp_string):
    punctuation = r"""!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~"""
    no_punct_string = re.sub(r'[{}]+'.format(punctuation), '', inp_string)
    return no_punct_string

with open('text.txt', encoding='UTF-8') as f:
    content = f.read()

content = content.replace("\n"," ").lower()
content = content.split(' ')


i = 0
list_no_punctuation = []
for word in content:
    text_no_punctuation = re.sub(r'[^\w\s]', '', word)
    list_no_punctuation.append(text_no_punctuation)
    
# print(list_no_punctuation)
counter = Counter(list_no_punctuation)
counter=sorted(counter.items(),key=lambda x:x[1],reverse=True)
dictionary = dict(counter)
print(dictionary)
# print(dictionary)

