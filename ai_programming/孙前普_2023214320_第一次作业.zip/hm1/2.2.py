def binaryadd(a:str,b:str):
    res = ''
    res = str(bin(int(a, 2) + int(b, 2)))
    return res[2:];

res = binaryadd('1', '11')
print(res)