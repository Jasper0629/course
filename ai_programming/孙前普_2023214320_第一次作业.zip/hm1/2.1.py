def Max(list):
    
    # 数组最左边的起始位置
    left = 0
    #  数组最右边的起始位置
    right = len(list) - 1
    #  初始化最大面积
    max_area = 0
    #  死循环走完每一个位置的数组
    while left < right:
        #  判断如果右边的值大于左边的值 高就为左边的否则反之     因为是注水问题，需要选择最短的那个条边
        #  类似于木桶效应问题，如果不懂可以查看下方链接
        height = list[left] if list[left] < list[right] else list[right]
        #  计算面积公式   选出最大值
        max_area = max(max_area,(right - left) * height)
        #  判断数组中的值  如果左边的小于右边的那么左边的位置的加 1 否则反之
        if list[left] < list[right]:
            left += 1
        else:
            right -= 1

    return max_area

if __name__ == "__main__":
    list = [1,8,6,2,5,4,8,3,7]
    max_area = Max(list)
    print(max_area)
